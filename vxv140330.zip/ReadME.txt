Vishal Venkat Raman
vxv140330


To run the program, open the R code in RStudio, select the whole program and click on run. The output should be visible in the console window. 
Note: When the script is executed for the first time, it might take some time for installing the packages. This is not required after the first time.

The main packages I've used for this assignment,
rpart
caret
klaR
e1071
neuralnet
nnet
MASS
glmnet

Others are mentioned in the code. 

The analysis for the different classifiers and dataset information is provided in the doc file attached. 